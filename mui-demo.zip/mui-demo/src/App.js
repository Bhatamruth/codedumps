import React from 'react';
import { Container, Typography, Button } from '@mui/material';
import ComboBox from './ComboBox'; // Import the ComboBox component
import top100Films from './top100Films'; // Import the top100Films data
import Playground from './Playground';
import GroupHeader from './GroupHeader';
import FloatingActionButtons from './FloatingActionButtons';
import ContinuousSlider from './ContinuousSlider';
import SliderSizes from './SliderSizes';
import DiscreteSlider from './DiscreteSlider';
import DiscreteSliderValues from './DiscreteSliderValues';
import RangeSlider from'./RangeSlider';
import InputSlider from './InputSlider';
import ValueLabelComponent from './ValueLabelComponent';
import MusicPlayerSlider from './MusicPlayerSlider';
function App() {
  return (
    <Container maxWidth="sm">
      <Typography variant="h3" gutterBottom>
        Welcome to Material-UI Demo
      </Typography>
      <Typography variant="body1" paragraph>
        This is a simple React app using Material-UI.
      </Typography>
      <ComboBox options={top100Films} /> {/* Use the ComboBox component */}
      <Playground/>
      <GroupHeader/>
      <FloatingActionButtons/>
      <SliderSizes/>
      <DiscreteSlider/>
      <DiscreteSliderValues/>
      <RangeSlider/>
      <InputSlider/>
      <MusicPlayerSlider/>
      <Button variant="contained" color="primary">
        Get Started
      </Button>
    </Container>
  );
}

export default App;
