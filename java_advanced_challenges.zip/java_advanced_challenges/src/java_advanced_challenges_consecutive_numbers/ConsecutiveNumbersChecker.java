package java_advanced_challenges_consecutive_numbers;
/*Write a method to determine consecutive numbers
Create a method in a Java class that accepts an array of numbers as a parameter. If the array of numbers can be rearranged so that they�re consecutive numbers where no number appears twice, return true. If this isn�t possible, return false. The array can be of any size.*/
import java.util.Arrays;

public class ConsecutiveNumbersChecker {
    public static void main(String[] args) {
        int[] numbers1 = {4, 2, 1, 3, 5}; 
        int[] numbers2 = {4, 2, 1, 3, 3, 5}; 
        
        System.out.println(canRearrangeToConsecutive(numbers1)); 
        System.out.println(canRearrangeToConsecutive(numbers2)); 
    }

    public static boolean canRearrangeToConsecutive(int[] numbers) {
        // Sort the array in ascending order
        Arrays.sort(numbers);

        // Check for duplicates
        for (int i = 0; i < numbers.length - 1; i++) {
            if (numbers[i] == numbers[i + 1]) {
                return false; 
            }
        }

        // Check if the difference between consecutive elements is 1
        for (int i = 0; i < numbers.length - 1; i++) {
            if (numbers[i + 1] - numbers[i] != 1) {
                return false; // Non-consecutive elements found
            }
        }

        return true; // No duplicates and consecutive elements found
    }
}
