package java_advanced_challenges_phone_number_word_decoder;
/*Write a phone number word decoder
Write a program in Java that�ll accept a phone number with letters and convert it to a phone number with only digits. For example, if you sent the program a phone number like 800888TEST, it should return (800) 888-8378.

Note that it shouldn�t only convert letters to the digits they represent but also format the number correctly with parentheses and dashes. And, if you send the program an invalid number, it should throw an error.*/
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class PhoneNumberDecoder {
    public static void main(String[] args) {
        String phoneNumberWithLetters = "800888TEST"; // Replace with the input phone number
        try {
            String phoneNumber = decodePhoneNumber(phoneNumberWithLetters);
            System.out.println("Decoded Phone Number: " + phoneNumber);
        } catch (IllegalArgumentException e) {
            System.err.println("Invalid phone number format: " + e.getMessage());
        }
    }

    public static String decodePhoneNumber(String phoneNumberWithLetters) {
        // Remove any non-alphanumeric characters and convert to uppercase
        String cleanPhoneNumber = phoneNumberWithLetters.replaceAll("[^a-zA-Z0-9]", "").toUpperCase();

        // Check if the cleaned phone number has exactly 10 digits
        if (cleanPhoneNumber.length() != 10) {
            throw new IllegalArgumentException("Phone number must have 10 digits.");
        }

        // Use regular expressions to insert parentheses and dashes
        Pattern pattern = Pattern.compile("(\\d{3})(\\d{3})(\\d{4})");
        Matcher matcher = pattern.matcher(cleanPhoneNumber);

        if (matcher.matches()) {
            String formattedPhoneNumber = "(" + matcher.group(1) + ") " + matcher.group(2) + "-" + matcher.group(3);
            return formattedPhoneNumber;
        } else {
            throw new IllegalArgumentException("Invalid phone number format.");
        }
    }
}
