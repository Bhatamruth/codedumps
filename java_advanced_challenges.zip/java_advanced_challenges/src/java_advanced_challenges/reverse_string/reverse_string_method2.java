package java_advanced_challenges.reverse_string;

public class reverse_string_method2 {
    public static void main(String[] args) {
        String input = "Hello, World!";
        String reversed = reverseString(input);
        System.out.println(reversed);
    }

    public static String reverseString(String input) {
        if (input.isEmpty()) {
            return input;
        } else {
            return reverseString(input.substring(1)) + input.charAt(0);
        }
    }
}
//in this im going to use recursion method and thats why there is no need of inbuilt function