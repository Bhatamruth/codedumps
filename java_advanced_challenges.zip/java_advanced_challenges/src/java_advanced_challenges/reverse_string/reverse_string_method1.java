package java_advanced_challenges.reverse_string;

public class reverse_string_method1 
{
	    public static void main(String[] args) {
	        String input = "Hello, World!";
	        String reversed = reverseString(input);
	        System.out.println(reversed);
	    }

	    public static String reverseString(String input) {
	        StringBuilder reversed = new StringBuilder();
	        for (int i = input.length() - 1; i >= 0; i--) {
	            reversed.append(input.charAt(i));
	        }
	        return reversed.toString();
	    }
	}
//in this is have used stringbuilder
/*A mutable sequence of characters. This class provides an API compatiblewith StringBuffer, 
but with no guarantee of synchronization.
This class is designed for use as a drop-in replacement for StringBuffer in places where the string buffer was beingused by a single thread (as is generally the case).
Where possible,it is recommended that this class be used in preference to StringBuffer as it will be faster under most implementations. 

The principal operations on a StringBuilder are the append and insert methods, 
which areoverloaded so as to accept data of any type. 
Each effectivelyconverts a given datum to a string and then appends or inserts thecharacters of that string to the string builder. 
The append method always adds these characters at the endof the builder; the insert method adds the characters ata specified point
*/