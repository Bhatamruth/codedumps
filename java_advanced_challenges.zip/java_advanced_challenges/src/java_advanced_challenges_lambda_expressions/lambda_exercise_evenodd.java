package java_advanced_challenges_lambda_expressions;
/*Write three Java lambda expressions
This exercise will test your ability to write lambda expressions in Java. Java lambda expressions take in parameters and return a value. They�re similar to methods but don�t need a name and can be implemented in the body of a method.

In this challenge, you�ll write three of them:

One that returns true if a number passed to it is odd and false if it�s even.
One that returns true if a number is prime and false if it�s not.
One that returns true if the parameter is a palindrome and false if it�s not.*/
public class lambda_exercise_evenodd {
		    public static void main(String[] args) {
		        int num = 5; // Replace with the number you want to check
		        boolean isOdd = checkIfOdd(num);
		        boolean isEven = checkIfEven(num);

		        System.out.println(num + " is odd: " + isOdd);
		        System.out.println(num + " is even: " + isEven);
		    }

		    public static boolean checkIfOdd(int num) {
		        OddChecker oddChecker = n -> n % 2 != 0;
		        return oddChecker.check(num);
		    }

		    public static boolean checkIfEven(int num) {
		        OddChecker oddChecker = n -> n % 2 != 0;
		        return !oddChecker.check(num);
		    }
		}

		@FunctionalInterface
		interface OddChecker {
		    boolean check(int num);
		}


