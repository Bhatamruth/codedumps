package java_advanced_challenges_consecutive_numbers_hexcode_in_string;

public class HexCodeFinder {
    public static void main(String[] args) {
        String inputString = "Hello, 0x776f726c64, how are you doing, 0x776f726c64?";
        String hexCode = "776f726c64"; // Hex-encoded string to search

        int index = findHexCode(inputString, hexCode);
        if (index != -1) {
            System.out.println("Hex code found at index: " + index);
        } else {
            System.out.println("Hex code not found in the input string.");
        }
    }

    public static int findHexCode(String input, String hexCode) {
        String decodedHex = hexToString(hexCode);

        int index = input.indexOf(decodedHex);

        return index;
    }

    public static String hexToString(String hex) {
        int len = hex.length();
        StringBuilder sb = new StringBuilder(len / 2);

        for (int i = 0; i < len; i += 2) {
            String hexPair = hex.substring(i, i + 2);
            char decodedChar = (char) Integer.parseInt(hexPair, 16);
            sb.append(decodedChar);
        }

        return sb.toString();
    }
}
