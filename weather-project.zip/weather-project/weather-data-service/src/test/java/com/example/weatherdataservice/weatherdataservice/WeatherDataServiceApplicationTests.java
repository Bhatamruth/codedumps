package com.example.weatherdataservice.weatherdataservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherDataServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
