package com.example.weatherdataservice.WeatherForecastService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherForecastServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
