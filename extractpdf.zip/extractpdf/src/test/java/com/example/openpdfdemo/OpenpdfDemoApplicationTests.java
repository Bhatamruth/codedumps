package com.example.openpdfdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpenpdfDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
